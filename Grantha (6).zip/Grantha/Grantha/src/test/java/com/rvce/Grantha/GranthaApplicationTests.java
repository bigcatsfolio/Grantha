package com.rvce.Grantha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GranthaApplicationTests {

	@Test
	void contextLoads() {
	}

}
