package com.rvce.Grantha.search_functionality.model;

import jakarta.persistence.*;

@Entity
@Table(name = "search_results") // This maps to a table in your database
public class SearchEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String bookName;
    private String pdfUrl;
    private String videoUrl;
    private String podcastUrl;

    // Constructors
    public SearchEntity() {}

    public SearchEntity(String bookName, String pdfUrl, String videoUrl, String podcastUrl) {
        this.bookName = bookName;
        this.pdfUrl = pdfUrl;
        this.videoUrl = videoUrl;
        this.podcastUrl = podcastUrl;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBookName() { return bookName; }
    public void setBookName(String bookName) { this.bookName = bookName; }

    public String getPdfUrl() { return pdfUrl; }
    public void setPdfUrl(String pdfUrl) { this.pdfUrl = pdfUrl; }

    public String getVideoUrl() { return videoUrl; }
    public void setVideoUrl(String videoUrl) { this.videoUrl = videoUrl; }

    public String getPodcastUrl() { return podcastUrl; }
    public void setPodcastUrl(String podcastUrl) { this.podcastUrl = podcastUrl; }
}