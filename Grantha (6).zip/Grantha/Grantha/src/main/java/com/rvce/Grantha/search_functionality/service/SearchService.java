package com.rvce.Grantha.search_functionality.service;

import com.rvce.Grantha.search_functionality.repository.SearchRepository;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Service
public class SearchService {

    @Autowired
    private SearchRepository searchRepository;

    public List<Object[]> search(String query) {
        return searchRepository.searchMedia(query);
    }
}