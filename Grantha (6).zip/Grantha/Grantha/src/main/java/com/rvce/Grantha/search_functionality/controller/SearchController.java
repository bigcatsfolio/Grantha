package com.rvce.Grantha.search_functionality.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import com.rvce.Grantha.search_functionality.service.SearchService;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @GetMapping
    public List<Map<String, String>> search(@RequestParam String query) {
        List<Object[]> results = searchService.search(query);

        return results.stream().map(obj -> Map.of(
                "type", (String) obj[0],
                "title", (String) obj[1],
                "author", (String) obj[2],
                "link", (String) obj[3]
        )).collect(Collectors.toList());
    }
}
