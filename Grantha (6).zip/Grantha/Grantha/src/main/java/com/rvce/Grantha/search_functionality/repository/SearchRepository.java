package com.rvce.Grantha.search_functionality.repository;

import com.rvce.Grantha.search_functionality.model.SearchEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SearchRepository extends JpaRepository<SearchEntity, Long> {

    @Query("""
        SELECT 'PDF' AS type, p.book_name AS title, p.author AS author 
        FROM pdf_links p
        WHERE LOWER(p.book_name) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(p.author) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(p.genre) LIKE LOWER(CONCAT('%', :query, '%'))

        UNION

        SELECT 'PODCAST' AS type, pod.book_name AS title, pod.author AS author
        FROM podcast_links pod
        WHERE LOWER(pod.book_name) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(pod.author) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(pod.genre) LIKE LOWER(CONCAT('%', :query, '%'))

        UNION

        SELECT 'VIDEO' AS type, v.book_name AS title, v.author AS author
        FROM video_link v
        WHERE LOWER(v.book_name) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(v.author) LIKE LOWER(CONCAT('%', :query, '%'))
        OR LOWER(v.genre) LIKE LOWER(CONCAT('%', :query, '%'))
    """)
    List<Object[]> searchMedia(@Param("query") String query);
}